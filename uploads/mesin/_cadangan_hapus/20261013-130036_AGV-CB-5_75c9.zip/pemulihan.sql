-- ============================================================================
--  PEMULIHAN: Unit "AGV CB 5" dari mesin AGV (dibuat lewat menu)
--  Dihapus permanen 2026-10-13 13:00:36 oleh djrmanik lewat menu Mesin & Unit (Checklist AM Warehouse CKR)
--  Cara memulihkan (developer): phpMyAdmin -> database web_wh -> tab SQL / Import -> jalankan file ini.
--  Lalu salin isi folder foto/ di zip ini ke uploads/mesin/ (kalau ada).
--  Hasil: unit kembali ke ARSIP di Mesin & Unit (tombol Pulihkan seperti biasa).
--  Aman dijalankan 2x (INSERT IGNORE / IF NOT EXISTS).
-- ============================================================================

SET NAMES utf8mb4;

-- checklist unit AGV CB 5 di tabel agv_table_top_lift (0)

-- registry genc_unit
INSERT IGNORE INTO `genc_unit` (`id`, `folder`, `profile`, `page`, `slug`, `label`, `kode`, `alias`, `builtin`, `aktif`, `urut`, `created_at`, `created_by`, `updated_at`, `updated_by`, `arsip`) VALUES
  (21, 'agv', 'agv_table_top_lift', 'agv_table_top_lift', 'agv-cb-5', 'AGV CB 5', '', '[]', 0, 0, 1, '2026-10-08 15:03:05', 'djrmanik', '2026-10-09 07:12:17', 'djrmanik', 1);

