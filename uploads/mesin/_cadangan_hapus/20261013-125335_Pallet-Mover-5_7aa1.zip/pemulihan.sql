-- ============================================================================
--  PEMULIHAN: Unit "Pallet Mover 5" dari mesin Pallet Mover & Stacker (dibuat lewat menu)
--  Dihapus permanen 2026-10-13 12:53:35 oleh djrmanik lewat menu Mesin & Unit (Checklist AM Warehouse CKR)
--  Cara memulihkan (developer): phpMyAdmin -> database web_wh -> tab SQL / Import -> jalankan file ini.
--  Lalu salin isi folder foto/ di zip ini ke uploads/mesin/ (kalau ada).
--  Hasil: unit kembali ke ARSIP di Mesin & Unit (tombol Pulihkan seperti biasa).
--  Aman dijalankan 2x (INSERT IGNORE / IF NOT EXISTS).
-- ============================================================================

SET NAMES utf8mb4;

-- checklist unit Pallet Mover 5 di tabel palletmover (1)
INSERT IGNORE INTO `palletmover` (`id`, `no_palletmover`, `garpu`, `handle`, `roda`, `hydraulic`, `body`, `tuas`, `date_created`, `user_created`, `date_update`, `approval`, `user_approve`, `kondisi`, `keterangan`, `user_update`, `charger_palletmover`, `air_aki`, `date_approve`) VALUES
  (1880, 'Pallet Mover 5', 'OK', 'OK', 'OK', 'OK', 'OK', 'OK', '2026-10-13 11:41:22', 'djrmanik', '', '', '', '✔️', 'OK', '', 'OK', 'OK', NULL);

-- registry genc_unit
INSERT IGNORE INTO `genc_unit` (`id`, `folder`, `profile`, `page`, `slug`, `label`, `kode`, `alias`, `builtin`, `aktif`, `urut`, `created_at`, `created_by`, `updated_at`, `updated_by`, `arsip`) VALUES
  (11, 'palletmover', 'palletmover', 'palletmover', 'pallet-mover-5', 'Pallet Mover 5', '', '[]', 0, 0, 1, '2026-10-08 07:33:11', 'djrmanik', '2026-10-13 11:41:30', 'djrmanik', 1);

