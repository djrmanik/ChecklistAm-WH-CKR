-- ============================================================================
--  PEMULIHAN: Unit "Pallet Mover 6" dari mesin Pallet Mover & Stacker (dibuat lewat menu)
--  Dihapus permanen 2026-10-13 13:00:25 oleh djrmanik lewat menu Mesin & Unit (Checklist AM Warehouse CKR)
--  Cara memulihkan (developer): phpMyAdmin -> database web_wh -> tab SQL / Import -> jalankan file ini.
--  Lalu salin isi folder foto/ di zip ini ke uploads/mesin/ (kalau ada).
--  Hasil: unit kembali ke ARSIP di Mesin & Unit (tombol Pulihkan seperti biasa).
--  Aman dijalankan 2x (INSERT IGNORE / IF NOT EXISTS).
-- ============================================================================

SET NAMES utf8mb4;

-- checklist unit Pallet Mover 6 di tabel palletmover (0)

-- registry genc_unit
INSERT IGNORE INTO `genc_unit` (`id`, `folder`, `profile`, `page`, `slug`, `label`, `kode`, `alias`, `builtin`, `aktif`, `urut`, `created_at`, `created_by`, `updated_at`, `updated_by`, `arsip`) VALUES
  (16, 'palletmover', 'palletmover', 'palletmover', 'pallet-mover-6', 'Pallet Mover 6', '', '[]', 0, 0, 2, '2026-10-08 14:56:36', 'djrmanik', '2026-10-09 07:12:48', 'djrmanik', 1);

